# Startplatz-Monitor – RAD-MARATHON Tannheimer Tal 2027, 214 km

Fragt alle ~5 min ab, wie viele Plätze die **214KM Einzel-Anmeldung** frei hat
(Feld `SlotsLeft` im JSON, das die RaceResult-Seite selbst lädt), und schickt
einen ntfy-Push aufs Handy, sobald es mehr als 0 sind.

## 1. Handy: ntfy einrichten
1. App **ntfy** installieren (App Store / Google Play).
2. „+“ → *Subscribe to topic* → langes, zufälliges Topic eintragen, Server `ntfy.sh` lassen.
   Das Topic ist praktisch das Passwort: Wer es kennt, kann mitlesen.
3. Optional (Android): Benachrichtigungen mit Priorität 5 dürfen „Nicht stören“ umgehen.

## 2. GitHub: Repo einrichten
1. github.com → **New repository** → Name z. B. `startplatz-monitor`, **Public**, ohne README.
2. Dateien hochladen: *Add file → Upload files* → `monitor.py`, `requirements.txt` hochziehen.
   Den Workflow separat anlegen: *Add file → Create new file* → als Namen
   `.github/workflows/monitor.yml` eintippen (die Schrägstriche legen die Ordner an) →
   Inhalt der Datei einfügen → *Commit*.
3. *Settings → Secrets and variables → Actions → New repository secret*:
   Name `NTFY_TOPIC`, Wert = dein Topic.
4. *Actions*-Tab → Workflow „Startplatz-Monitor 214 km“ → **Run workflow**.
5. Nach ~30 s kommt der Push „Monitor aktiv ✅ … aktuell 0 freie Plätze“.

## Pushes
| Ereignis | Priorität |
|---|---|
| Erster Lauf („Monitor aktiv“) | 2 |
| Freie Plätze > 0 bzw. Anzahl ändert sich | 5 (laut) |
| Wieder 0 Plätze | 3 |
| 3 Abruffehler in Folge | 3 |

## Grenzen
- GitHub-Cron: minimal alle 5 min, unter Last oft verspätet.
- Geplante Workflows in öffentlichen Repos pausieren nach 60 Tagen ohne Repo-Aktivität.
- Anmeldeformular ist laut Seiten-Config bis 01.07.2027 aktiv; danach Workflow deaktivieren.
